package com.todochat.todochat.models.enums;

public enum Status {
    PENDING, IN_PROGRESS, COMPLETED
}
