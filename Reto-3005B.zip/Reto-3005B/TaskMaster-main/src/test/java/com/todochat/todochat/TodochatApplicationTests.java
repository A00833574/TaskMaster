package com.todochat.todochat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodochatApplicationTests {

	@Test
	void contextLoads() {
	}

}
